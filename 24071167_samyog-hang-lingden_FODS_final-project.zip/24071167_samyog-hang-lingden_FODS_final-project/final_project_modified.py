import os
import sys
import matplotlib.pyplot as plt
import pandas as pd

# --- Cross-platform password input showing # ---
def input_password(prompt="Password: "):
    print(prompt, end='', flush=True)
    password = ''
    try:
        # Windows
        import msvcrt
        while True:
            char = msvcrt.getch()
            if char in {b'\r', b'\n'}:
                print('')
                break
            elif char == b'\x08':
                if len(password) > 0:
                    password = password[:-1]
                    print('\b \b', end='', flush=True)
            elif char == b'\x03':
                raise KeyboardInterrupt
            else:
                password += char.decode()
                print('#', end='', flush=True)
    except ImportError:
        # Unix/Linux/macOS
        import tty
        import termios
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            while True:
                char = sys.stdin.read(1)
                if char in {'\r', '\n'}:
                    print('')
                    break
                elif char == '\x7f':
                    if len(password) > 0:
                        password = password[:-1]
                        print('\b \b', end='', flush=True)
                elif char == '\x03':
                    raise KeyboardInterrupt
                else:
                    password += char
                    print('#', end='', flush=True)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return password

# --- Helper functions ---
def load_data(filename):
    try:
        with open(filename, 'r') as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        return []

def save_data(filename, lines):
    with open(filename, 'w') as f:
        for line in lines:
            f.write(line + "\n")

# --- Base Classes ---
class User:
    def __init__(self, username):
        self.username = username

    @staticmethod
    def login():
        users = load_data("passwords.txt")
        while True:
            username = input("Username: ")
            password = input_password("Password: ")  # <-- Modified to show #
            for line in users:
                u, p = line.split(',')
                if u == username and p == password:
                    role = User.get_role(username)
                    print(f"Login successful as {role}")
                    if role == 'admin':
                        return Admin(username)
                    elif role == 'student':
                        return Student(username)
            print("Invalid credentials. Try again.")

    @staticmethod
    def get_role(username):
        for line in load_data("users.txt"):
            parts = line.split(',')
            if parts[0] == username:
                return parts[2]
        return None

    @staticmethod
    def signup():
        print("\n--- Student Signup ---")
        username = input("Choose a username: ")
        existing_users = load_data("users.txt")
        if any(line.startswith(username + ",") for line in existing_users):
            print("Username already exists.")
            return
        name = input("Enter your full name: ")
        password = input_password("Choose a password: ")  # <-- Modified
        grades = input("Enter 5 subject grades separated by commas (e.g., 80,85,90,75,88): ")
        eca = input("Enter ECA activities separated by semicolons (e.g., Football;Drama): ")

        with open("users.txt", 'a') as f:
            f.write(f"{username},{name},student\n")
        with open("passwords.txt", 'a') as f:
            f.write(f"{username},{password}\n")
        with open("grades.txt", 'a') as f:
            f.write(f"{username},{grades}\n")
        with open("eca.txt", 'a') as f:
            f.write(f"{username},{eca}\n")

        print("Signup successful. You can now login!")

class Admin(User):
    def __init__(self, username):
        super().__init__(username)

    def add_user(self):
        username = input("Enter new username: ")
        if any(u.startswith(username + ",") for u in load_data("users.txt")):
            print("User already exists.")
            return
        name = input("Enter full name: ")
        role = input("Enter role (student only allowed for now): ").lower()
        password = input_password("Enter password: ")  # <-- Modified
        with open("users.txt", 'a') as f:
            f.write(f"{username},{name},{role}\n")
        with open("passwords.txt", 'a') as f:
            f.write(f"{username},{password}\n")
        if role == 'student':
            grades = input("Enter 5 subject grades separated by commas: ")
            eca = input("Enter ECA activities separated by semicolon: ")
            with open("grades.txt", 'a') as f:
                f.write(f"{username},{grades}\n")
            with open("eca.txt", 'a') as f:
                f.write(f"{username},{eca}\n")
        print("User added successfully.")

    def update_user(self):
        username = input("Enter student username to update: ")
        users = load_data("users.txt")
        found = False
        for i, line in enumerate(users):
            if line.startswith(username + ","):
                new_name = input("Enter new full name: ")
                users[i] = f"{username},{new_name},student"
                save_data("users.txt", users)
                print("User info updated.")
                found = True
                break
        if not found:
            print("User not found.")

    def delete_user(self):
        username = input("Enter student username to delete: ")
        for filename in ["users.txt", "grades.txt", "eca.txt", "passwords.txt"]:
            lines = [line for line in load_data(filename) if not line.startswith(username + ",")]
            save_data(filename, lines)
        print("User deleted.")

    def insights(self):
        grades = load_data("grades.txt")
        eca = load_data("eca.txt")

        total = [0]*5
        count = 0
        student_data = []

        for line in grades:
            parts = line.split(',')
            username = parts[0]
            scores = list(map(int, parts[1:]))
            total = [t + s for t, s in zip(total, scores)]
            student_data.append((username, sum(scores)/len(scores)))
            count += 1

        if count > 0:
            avg = [round(t / count, 2) for t in total]
            print("Average Grades per Subject:", avg)
            plt.plot([f"Sub{i+1}" for i in range(5)], avg, marker='o')
            plt.title("Average Grade Trends")
            plt.ylabel("Marks")
            plt.grid(True)
            plt.show()
        else:
            print("No grades data.")

        eca_scores = {line.split(',')[0]: len(line.split(',')[1].split(';')) for line in eca}
        for username, avg_grade in student_data:
            eca_count = eca_scores.get(username, 0)
            print(f"{username} - Avg Grade: {avg_grade}, ECA Count: {eca_count}")

        underperformers = [u for u, g in student_data if g < 50]
        if underperformers:
            print("\nPerformance Alerts: Students below threshold (Avg < 50):")
            for u in underperformers:
                print(f"- {u} needs academic intervention.")
        else:
            print("\nAll students are performing above threshold.")

class Student(User):
    def __init__(self, username):
        super().__init__(username)

    def view_profile(self):
        for line in load_data("users.txt"):
            if line.startswith(self.username + ","):
                print("Profile:", line)
        for line in load_data("grades.txt"):
            if line.startswith(self.username + ","):
                print("Grades:", ", ".join(line.split(',')[1:]))
        for line in load_data("eca.txt"):
            if line.startswith(self.username + ","):
                print("ECA:", line.split(',')[1])

    def update_profile(self):
        users = load_data("users.txt")
        for i, line in enumerate(users):
            if line.startswith(self.username + ","):
                new_name = input("Enter new full name: ")
                users[i] = f"{self.username},{new_name},student"
                save_data("users.txt", users)
                print("Profile updated.")
                return

    def visualize_grades(self):
        for line in load_data("grades.txt"):
            if line.startswith(self.username + ","):
                grades = list(map(int, line.split(',')[1:]))
                plt.bar([f"Sub{i+1}" for i in range(5)], grades)
                plt.title("Your Grades")
                plt.ylabel("Marks")
                plt.show()
                return
        print("No grades found.")

# --- Main Menu ---
def main():
    print("***************************************")
    print("*  Welcome to Student Profile System  *")
    print("***************************************")
    while True:
        print("\n1. Login")
        print("2. Signup")
        print("3. Exit")
        choice = input("Enter your choice: ")
        if choice == '1':
            user = User.login()
            if isinstance(user, Admin):
                while True:
                    print("\nAdmin Menu:")
                    print("1. Add User")
                    print("2. Update User")
                    print("3. Delete User")
                    print("4. View Insights")
                    print("5. Logout")
                    a_choice = input("Choice: ")
                    if a_choice == '1':
                        user.add_user()
                    elif a_choice == '2':
                        user.update_user()
                    elif a_choice == '3':
                        user.delete_user()
                    elif a_choice == '4':
                        user.insights()
                    elif a_choice == '5':
                        break
                    else:
                        print("Invalid choice.")
            elif isinstance(user, Student):
                while True:
                    print("\nStudent Menu:")
                    print("1. View Profile")
                    print("2. Update Profile")
                    print("3. Visualize Grades")
                    print("4. Logout")
                    s_choice = input("Choice: ")
                    if s_choice == '1':
                        user.view_profile()
                    elif s_choice == '2':
                        user.update_profile()
                    elif s_choice == '3':
                        user.visualize_grades()
                    elif s_choice == '4':
                        break
                    else:
                        print("Invalid choice.")
        elif choice == '2':
            User.signup()
        elif choice == '3':
            print("Goodbye!")
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()
